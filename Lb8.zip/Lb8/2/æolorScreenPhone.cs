﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lb8_2
{
    public class СolorScreenPhone : BlackWhitePhone
    {
        public int CountOfColors { get; set; }
        public bool SupportDualSim { get; set; }
        public string SecondNumber { get; set; }
    }
}
