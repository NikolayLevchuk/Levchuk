﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lb8_2
{
    public class ButtonPhone : BasePhone
    {
        public ButtonPhone()
        {
            AvailableNumbers.AddRange(new List<string>
            {
                "Enter",
                "Cancel",
                "*",
                "#"
            });
        }
    }
}
