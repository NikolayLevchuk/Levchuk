﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace labka3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "Натисніть кнопку “Ок”!!!";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        private void Move(object sender, MouseEventArgs e)
        {
            int width = (int)this.button1.Size.Width;
            int height = (int)this.button1.Size.Height;
            Random x = new Random();
            Random y = new Random();
            int x1 = Convert.ToInt32(x.Next(100, 250));
            int y1 = Convert.ToInt32(y.Next(150, 300));
            button1.Location = new Point(x1, y1);
            this.button1.Size = new System.Drawing.Size(width - 5, height - 5);
            if (width < 5 || height < 5)
            {
                MessageBox.Show("Кнопка “Ок” не може бути натиснута");
            }
        }
    }
}

