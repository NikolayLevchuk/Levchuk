﻿using System;
using System.Collections.Generic;
using System.Text;
namespace Samost
{

    class Beer
    {
        public string Name { get; set; }
        public int Vitrimka { get; set; }
        public string Country { get; set; }
        public float Price { get; set; }
        public override string ToString()

        {
            return $"Name:{Name}\t Vitrimka: {Vitrimka}\t Country: {Country}\t Price: {Price}";
        }
        static void Main(string[] args)
        {
            var g = new Shop();
            var flag = true;
            while (flag)
            {
                Console.WriteLine("1 - найти пиво в магазине по параметрам");
                Console.WriteLine("2 - выход");
                Console.Write("Опция > ");
                var option = int.Parse(Console.ReadLine());
                switch (option)
                {
                    case 1: g.SearchBeerName(); g.SearchBeerVitrmka(); g.SearchBeerCountry(); g.SearchBeerPrice(); break;
                    case 2: flag = false; break;
                    default: Console.WriteLine("Упс"); break;
                }
            }
        }

    }
}