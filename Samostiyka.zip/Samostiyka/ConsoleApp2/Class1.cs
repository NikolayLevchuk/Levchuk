﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Samost
{
    class Shop
    {
        List<Beer> beer = new List<Beer>()
        {
            new Beer() { Name = "Hineken", Vitrimka = 1, Country = "Germany", Price = 25.50f },     
            new Beer() { Name = "Bud", Vitrimka = 1, Country = "USA", Price = 25.50f },
            new Beer() { Name = "Jiguli", Vitrimka = 2, Country = "Ukraine", Price = 25.50f },
            new Beer() { Name = "Lowenbrau", Vitrimka = 3, Country = "Germany", Price = 25.50f },
            new Beer() { Name = "Zibert", Vitrimka = 2, Country = "Germany", Price = 25.50f }
        };
        public void SearchBeerName()
        {
            Console.WriteLine("Название пива: ");
            string name = Console.ReadLine();
            var beers = beer.FirstOrDefault(d => d.Name == name);
            if (beers == null) Console.WriteLine("Такого пива нет.");
            else
                Console.WriteLine($"Name:{beers.Name}\t Vitrimka: {beers.Vitrimka}\t Country: {beers.Country}\t Price: { beers.Price}");
        }
        public void SearchBeerVitrmka()
        {
            Console.WriteLine("Витримка пива: ");
            int vitrimka = int.Parse(Console.ReadLine());
            var beers = beer.FirstOrDefault(d => d.Vitrimka == vitrimka);
            if (beers == null)
            {
                Console.WriteLine("Такого пива нет. ");
                return;
            }
            else
                Console.WriteLine($"Name:{beers.Name}\t Vitrimka: {beers.Vitrimka}\t Country: {beers.Country}\t Price: { beers.Price}");
        }
        public void SearchBeerCountry()
        {
            Console.WriteLine("Країна: ");
            string country = Console.ReadLine();
            var beers = beer.FirstOrDefault(d => d.Country == country);
            if (beers == null)
            {
                Console.WriteLine("Такого пива нет");
                return;
            }
            else
                Console.WriteLine($"Name:{beers.Name}\t Vitrimka: {beers.Vitrimka}\t Country: {beers.Country}\t Price: { beers.Price}");
        }
        public void SearchBeerPrice()
        {
            Console.WriteLine("Цена:");
            float Price = float.Parse(Console.ReadLine());
            var beers = beer.FirstOrDefault(d => d.Price == Price);
            if (beers == null)
            {
                Console.WriteLine("Такого пива нет");
                return;
            }
            else
                Console.WriteLine($"Name:{beers.Name}\t Vitrimka: {beers.Vitrimka}\t Country: {beers.Country}\t Price: { beers.Price}");
        }
    }
}