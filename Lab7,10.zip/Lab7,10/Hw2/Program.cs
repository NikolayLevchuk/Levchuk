﻿using System;

namespace Lab10
{
    class Program
    {
        static void Main(string[] args)
        {
            var arr = new int[] { 4, 73, 96, 36, 3, 84, 9347 };
            var newarray = arr.GetArray();
        }
    }
}
