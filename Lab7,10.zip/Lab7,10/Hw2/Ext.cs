﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab10
{
    public static class Ext
    {
        public static int[] GetArray(this int[] arr)
        {
            return arr.OrderBy(d => d).ToArray();
        }
    }
}
