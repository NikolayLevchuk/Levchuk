﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Lab7
{
    public class Data
    {
        private List<object> lists;
        public Data()
        {
            lists = new List<object>();
        }

        public List<object> Elements => lists;

        public void Add(object el) => lists.Add(el);

        public void AddElements(List<object> objs) => lists.AddRange(objs);

        public int CountOfInt()
        {
            int count = 0;
            foreach (var item in lists)
            {
                if(item is int)
                {
                    count++;
                }
            }
            return count;
        }
        public int CountOfDouble()
        {
            int count = 0;
            foreach (var item in lists)
            {
                if (item is double)
                {
                    count++;
                }
            }
            return count;
        }
        public int CountOfChar()
        {
            int count = 0;
            foreach (var item in lists)
            {
                if (item is char)
                {
                    count++;
                }
            }
            return count;
        }
        public int CountOfBool()
        {
            int count = 0;
            foreach (var item in lists)
            {
                if (item is bool)
                {
                    count++;
                }
            }
            return count;
        }
        public int CountOfString()
        {
            int count = 0;
            foreach (var item in lists)
            {
                if (item is string)
                {
                    count++;
                }
            }
            return count;
        }
    }
}