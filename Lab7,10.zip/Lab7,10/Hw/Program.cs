﻿using System;
using System.Collections.Generic;

namespace Lab7
{
    class Program
    {
        static void Main(string[] args)
        {
            Data data = new Data();
            data.AddElements(new List<object>
            {
                1,
                2,
                3,
                "sdf",
                'f',
                "wg",
                true
            });
            Console.WriteLine(data.CountOfBool());
            Console.WriteLine();
            Console.WriteLine(data.CountOfChar());
        }
    }
}
